package test.scenarious;

import java.io.IOException;

import org.testng.Reporter;
import org.testng.annotations.Test;

import METHODS.CartMethod;

public class CartPageTest extends ProductsPageTest {
	static CartMethod cart;

	@Test (dependsOnMethods = {"products"} , description = "This test is for cart page")
	public void CartPage() {
		cart = new CartMethod();

		cart.ClickCartPage();
		cart.ClickCheckoutFromCart();
		cart.ClickOnRemoveImacButton();
		cart.ClickCheckoutButton();
	}

	@Test(description = "This test is for sceenshot")
	public void Screenshot() throws IOException {
		if(cart == null) {
			cart = new CartMethod();
		}
		cart.Screenshot(driver);
		Reporter.log("Browser is closed", true);
	}
}