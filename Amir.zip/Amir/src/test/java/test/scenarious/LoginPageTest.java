package test.scenarious;

import org.junit.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import METHODS.LoginMethod;

public class LoginPageTest extends BaseClass {
	LoginMethod LoginPageOne;

	
	@Test(enabled = true)
	public void login() throws InterruptedException {
		driver.get(props.getProperty("WEBSITELOGINURL1"));

		LoginPageOne = new LoginMethod(driver);
		LoginPageOne.loginPageWithValiDetails(props.getProperty("email"), props.getProperty("loginPassword"));
		Reporter.log("Username And Password are Entered",true);
		LoginPageOne.clickLoginBtn();
		Reporter.log("Login Button clicked", true);

		Assert.assertEquals(props.getProperty("assertLogin"), LoginPageOne.getEditProfileText());
	}

}
