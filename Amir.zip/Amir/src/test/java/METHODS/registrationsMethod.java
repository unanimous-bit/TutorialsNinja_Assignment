package METHODS;

import org.openqa.selenium.WebDriver;
import org.testng.Reporter;

import page.objects.loginpageNinja;
import page.objects.registrationpageNinja;

public class registrationsMethod {
	WebDriver driver;
	registrationpageNinja registerPage ;
	
	public registrationsMethod(WebDriver driver) {
		
		this.driver = driver;
		 registerPage = new registrationpageNinja(driver);
	}
	public void reregistrationPage(String firstname, String lastname, String useremail, String Telephone,
			String password, String confirmpass, String checkbox) {
		registerPage.getFirstnameTextfiled().clear();
		registerPage.getFirstnameTextfiled().sendKeys(firstname);
		Reporter.log("firstname is entered into testField\n");
		registerPage.getLastnameTextfield().clear();
		registerPage.getLastnameTextfield().sendKeys(lastname);
		Reporter.log("lastname is entered into testField");
		registerPage.getEmailidTextfield().clear();
		registerPage.getEmailidTextfield().sendKeys(useremail);
		Reporter.log("userEmail is entered into testField");
		this.registerPage.getTelephoneTextfield().clear();
		this.registerPage.getTelephoneTextfield().sendKeys(Telephone);
		Reporter.log("Telephone number entered in Testfield");
		this.registerPage.getPasswordTextfield().clear();
		this.registerPage.getPasswordTextfield().sendKeys(password);
		Reporter.log("Password entered in Testfield");
		this.registerPage.getConfirmpassTextfield().clear();
		this.registerPage.getConfirmpassTextfield().sendKeys(confirmpass);
		Reporter.log("Confirm Password entered in Testfield");

	}

	public void registrationPage(String firstname, String lastname, String useremail, String Telephone, String password,
			String confirmpass) {
		registerPage.getFirstnameTextfiled().clear();
		registerPage.getFirstnameTextfiled().sendKeys(firstname);
		Reporter.log("firstname is entered into testField\n");
		registerPage.getLastnameTextfield().clear();
		registerPage.getLastnameTextfield().sendKeys(lastname);
		Reporter.log("lastname is entered into testField");
		registerPage.getEmailidTextfield().clear();
		registerPage.getEmailidTextfield().sendKeys(useremail);
		Reporter.log("userEmail is entered into testField");
		this.registerPage.getTelephoneTextfield().clear();
		this.registerPage.getTelephoneTextfield().sendKeys(Telephone);
		Reporter.log("Telephone number entered in Testfield");
		this.registerPage.getPasswordTextfield().clear();
		this.registerPage.getPasswordTextfield().sendKeys(password);
		Reporter.log("Password entered in Testfield");
		this.registerPage.getConfirmpassTextfield().clear();
		this.registerPage.getConfirmpassTextfield().sendKeys(confirmpass);
		Reporter.log("Confirm Password entered in Testfield");

	}

	public void clickregistrationButton() {
		registerPage.getRegisterButton().click();
		Reporter.log("Registration Button is clicked");
	}

	public void setCheckbox() {
		registerPage.getCheckbox().click();
	}

	public void clickMyaccount() {
		registerPage.getMyaccountButton();
	}

	public void clickLogout() throws InterruptedException {
		registerPage.getLogoutButton().click();
		
	}

	public String getregistererrorMessage() {
		return registerPage.getRegistrationerrorMessage().getText();
	}
}



