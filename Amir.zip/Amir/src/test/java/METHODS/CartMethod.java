package METHODS;

import java.io.File;
import java.io.IOException;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.Reporter;

import page.objects.CartPageNinja;
import test.scenarious.BaseClass;

public class CartMethod {
	WebDriver driver;
	CartPageNinja CartPage;

	public void ClickCartPage() {
		driver = BaseClass.getdriver();
		CartPage = new CartPageNinja(driver);
		CartPage.getCartpageButton().click();
		Reporter.log("Clicked on Cart Page", true);
	}

	public void ClickCheckoutFromCart() {

		CartPage.getCheckoutfromcartButton().click();
		Reporter.log("Clicked on Checkout Page", true);
	}

	public void ClickOnRemoveImacButton() {

		CartPage.getRemoveImacCrossButton().click();
		Reporter.log("Clicked on remove product iMac from Checkout Page\n", true);
	}

	public void ClickCheckoutButton() {

		CartPage.getCheckoutButton().click();
		Reporter.log("Clicked on Checkout Page\n", true);
	}

	public void Screenshot(WebDriver driver) throws IOException {

		Date currentdate = new Date();
		System.out.println("currentdate");
		String screenshotfilename = ".//ssfolder//" + currentdate.toString().replace(" ", ",").replace(":", "-")
				+ ".png";
		Reporter.log(screenshotfilename, true);
		TakesScreenshot scrShot = ((TakesScreenshot) driver);
		File SrcFile = scrShot.getScreenshotAs(OutputType.FILE);
		File DestFile = new File(screenshotfilename);
		FileUtils.copyFile(SrcFile, DestFile);
		Reporter.log("ScreenShot is Taken", true);

	}

}
