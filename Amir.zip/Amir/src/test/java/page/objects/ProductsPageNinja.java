package page.objects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

//import io.github.bonigarcia.wdm.WebDriverManager;

public class ProductsPageNinja {

	WebDriver driver;
	static int compCount = 0;
	String parentWindow;

	public ProductsPageNinja(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//ul[@class='nav navbar-nav']/li/a[contains(text(),'Desktops')]")
	private WebElement HoverDesktopLink;

	@FindBy(xpath = "//a[normalize-space()='Mac (1)']")
	private WebElement MacLink;

	@FindBy(xpath = "//span[normalize-space()='Add to Cart']")
	private WebElement ImacAddtocartButton;

	@FindBy(xpath = "//i[@class='fa fa-home']")
	private WebElement homepageButton;

	@FindBy(xpath = "//a[normalize-space()='Tablets']")
	private WebElement TabletsButton;

	@FindBy(xpath = "//div[@class='product-layout product-grid col-lg-4 col-md-4 col-sm-6 col-xs-12']//button[1]")
	private WebElement samsungtabButton;

	@FindBy(xpath = "//div[@class='alert alert-success alert-dismissible']")
	private WebElement compareMessage;

	@FindBy(xpath = "//*[@id=\"content\"]/div[2]/div/div/div[2]/div[1]/h4/a")
	private WebElement iMacsave;

	@FindBy(xpath = "//a[contains(text(),'Reviews')]")
	private WebElement productReview;

	@FindBy(xpath = "//*[@id=\"content\"]/div[2]/div/div/div[2]/div[1]/h4/a")
	private WebElement samsungTabletsave;

	@FindBy(xpath = "//div[@class='caption']//a[contains(text(),'Samsung Galaxy Tab 10.1')]")
	private WebElement samsungtabletProductname;// dont use product name for comapre

	public WebDriver getDriver() {
		return driver;
	}

	public static int getCompCount() {
		return compCount;
	}

	public WebElement getHoverdesktopLink() {
		return HoverDesktopLink;
	}

	public WebElement getMacLink() {
		return MacLink;
	}

	public WebElement getImacaddtocartButton() {
		return ImacAddtocartButton;
	}

	public WebElement getHomepageButton() {
		return homepageButton;
	}

	public WebElement getTabletsButton() {
		return TabletsButton;
	}

	public WebElement getSamsungtabButton() {
		return samsungtabButton;
	}

	public WebElement getCompareMessage() {
		return compareMessage;
	}

	public WebElement getiMacsave() {
		return iMacsave;
	}

	public WebElement getProductReview() {
		return productReview;
	}

	public WebElement getSamsungTabletsave() {
		return samsungTabletsave;
	}

	public WebElement getSamsungtabletProductname() {
		return samsungtabletProductname;
	}
}
